<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>U-BUNG ONLINE SYSTEM</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
<div class="sidebar">
  <a href="#home">Home</a>
  <a href="#login">Login</a>
  <a href="#despatcher">Despatcher</a>
  <a class="active" href="startbootstrap-sb-admin-gh-pages/index.html">Restaurant</a>
  <a href="#admin">Admin</a>
  <a href="#about">About</a>
</div>
  
  <?php include('template/header.php');?>
  
  <section class="container grey-text">
  <h4 style="margin-left: 240px" class="center">Restaurant Sign Up Form</h4>
   <p style="margin-left: 420px">Please fill in the information:</p>
  <form style="margin-left: 420px" class="white" method="POST">
  
  <label>Restaurant name:</label>
  <input type="text" name="rest_name" placeholder="Enter Restaurant Name" required>
  <label>Owner name:</label>
  <input type="text" name="rest_owner" placeholder="Enter Restaurant Owner Name" required>
  <label>Contact number:</label>
  <input type="text" name="rest_contactnum" placeholder="Enter Restaurant Contact Number" required>
  <label>Address:</label>
  <input type="text" name="rest_address" placeholder="Enter Restaurant Address" required>
  <label>E-mail:</label>
  <input type="text" name="rest_email" placeholder="Enter Restaurant E-mail" required>
  <label>Username</label>
  <input type="text" name="rest_username" placeholder="Enter Username" required>
  <label>Password:</label>
  <input type="password" name="rest_password" placeholder="Set Password (e.g abc123)" required>
  <div class="center">
  <input type="submit" name="SignUp" value="Sign Up" class="btn brand z-depth-0">
  </div>
  <p>Already register?<a href="login_rest.php"> Click here</a> to login now</p>
  </form>
  </section>
 
<?php include('template/footer.php');?>

</body>
</html>

<?php
include_once"connection.php";
?>

<?php
// Escape user inputs for security
if (isset($_POST['SignUp']))
{
	$srest_name = $_REQUEST['rest_name'];
	$srest_owner = $_REQUEST['rest_owner'];
	$srest_contactnum = $_REQUEST['rest_contactnum'];
	$srest_address = $_REQUEST['rest_address'];
	$srest_email = $_REQUEST['rest_email'];
  $srest_username = $_REQUEST['rest_username'];
	$srest_password = $_REQUEST['rest_password'];

	//Insert data into database
	if ($srest_name=='' || $srest_owner=='' || $srest_contactnum=='' || $srest_address=='' || $srest_email==''|| $srest_username =='' || $srest_password=='')
	{
		echo "Incomplete information. No data inserted.";
	}
	else
	{
		$sql = "INSERT INTO restaurant (rest_name, rest_owner, rest_contactnum, rest_address, rest_email, rest_username, rest_password)
		VALUES('$srest_name', '$srest_owner', '$srest_contactnum', '$srest_address' , '$srest_email', '$srest_username', '$srest_password')";

		if ($con->query($sql) === TRUE) 
		{
	    	
			  echo "<script>alert('Registration is successfull. Now you may login.');</script>";"<br>";

		} 
		else 
		{
    		echo "Error: " . $sql . "<br>" . $con->error;
		}
	}	
}

$con->close();
?>