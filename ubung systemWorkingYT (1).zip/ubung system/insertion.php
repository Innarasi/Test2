<html>
<body>

<?php

require_once'connection.php';//Database Connection File
	session_start();
	

$rest_id= $_GET['rest_id'];

	$menu_id = $_POST["menu_id"];
	$menu_name = $_POST["menu_name"];
	//$menu_img = $_POST["menu_img"];
	$menu_Description = $_POST["menu_Description"];
	$menu_Price = $_POST["menu_Price"];


	$sql = "INSERT INTO menu(menu_id, menu_name,  menu_Description, menu_Price,rest_id) VALUES ('$menu_id', '$menu_name', '$menu_Description','$menu_Price','$rest_id')";

	$result = mysqli_query($con, $sql);

	if($result){
		echo "<script>alert('Insertion is successful')</script>";
		echo "<script>window.open('update_menu.php?rest_id=$rest_id','_self')</script>";
	}
?>
</body>
</html>