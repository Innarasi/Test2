<!DOCTYPE html>
<?php
	require_once'connection.php';//Database Connection File
	session_start();
	$rest_username = $_SESSION["rest_username"];
	
$links = mysqli_connect("localhost", "root", "", "u-bung_system") or die (mysqli_error());
$strSQL = "select * from restaurant where rest_username='$rest_username'";
$rs = mysqli_query($links, $strSQL);
$row=mysqli_fetch_array($rs);

$rest_id= $row['rest_id'];

?>

<?php
if(isset($_POST['submitform']))
      {
      	//require_once'connection.php';
        $result = mysqli_query($con,"SELECT * FROM menu WHERE rest_id='$rest_id'");
		$query="SELECT * FROM menu WHERE rest_id='$rest_id'";
		$result=mysqli_query($con,$query);
		//$menu_id= $row['menu_id'];		   
		$row = mysqli_fetch_array($result);
        
		
		$dir="images/";
      	$image =  $_FILES['uploadfile']['name'];
      	$temp_name=$_FILES['uploadfile']['tmp_name'];

      	if($image!="")
      {
        if(file_exists($dir.$image))
        {
          $image= time().'_'.$image;
        }

        $fdir= $dir.$image;
        move_uploaded_file($temp_name, $fdir);
      }
      
        $query="UPDATE menu SET menu_img='$image' WHERE rest_id='$rest_id'";
        $result = mysqli_query($con,$query);
        //$row = mysqli_fetch_array($result);
        
        if($result){
            echo "<script>alert('Menu picture upload successfull.');</script>";
        } else {
            echo "<script>alert('Something went wrong. Please try again');</script>";
        }
     
     }


?>

<html>
<head>
	<title>U-BUNG ONLINE SYSTEM</title>
	<meta http-equiv="content-type" content="text/html" charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
<div class="sidebar">
  <a href="#home">Home</a>
  <a href="#login">Login</a>
  <a href="#despatcher">Despatcher</a>
  <a class="active" href="startbootstrap-sb-admin-gh-pages/index.html">Restaurant</a>
  <a href="#admin">Admin</a>
  <a href="#about">About</a>
</div>
<?php include('template/header.php');?>
	<section class="container grey-text">
	<h4 style="margin-left: 320px" class="center">Restaurant Menu
		<a href="logout.php" class="btn brand z-depth-0" style="float:right">Log Out</a>
	</h4>
  
	<a href="insert_menu.php?rest_id=<?php echo $rest_id;?>"><button class="btn brand z-depth-0">Add Menu</button></a>
	<a href="rest_profile.php?rest_id=<?php echo $rest_id;?>" method="post"> <input class="btn brand z-depth-0" type="submit" name="back" value="Back"> </a>
	<br><br>
		<table style="width:120%">
		
		<col width="150">

			<tr>
				<th style="text-align:center"bgcolor="#404040"><b>Menu ID &nbsp </th>
				<th style="text-align:center"bgcolor="#404040"><b>Menu Name &nbsp </th>
				<th style="text-align:center"bgcolor="#404040"><b>Menu Image &nbsp </th>
				<th style="text-align:center"bgcolor="#404040"><b>Menu Description &nbsp </th>
				<th style="text-align:center"bgcolor="#404040"><b>Menu Price (RM) &nbsp </th>
				<th style="text-align:center" bgcolor="#404040"><b>Action &nbsp </th>
			</tr>
				
				<?php $result = mysqli_query($con,"SELECT * FROM menu WHERE rest_id='$rest_id'");
				 $query="SELECT * FROM menu WHERE rest_id='$rest_id'";
				   $result=mysqli_query($con,$query);
				   
				   while($row = mysqli_fetch_array($result)):?>
					   
			<tr>
				<td align="center"><?php echo $row['menu_id'];?></td>
				<td align="center"><?php echo $row['menu_name'];?></td>
				<td ><img src="images/<?php echo $row['menu_img']; ?>" width=300 height=200 alt="image"></td>
				<td align="center"><?php echo $row['menu_Description'];?></td>
				<td align="center"><?php echo $row['menu_Price'];?></td>
				<td align="center"> <a href="delete_menu.php?menu_id=<?php echo $row['menu_id'];?> "><button style="margin-left: 20px"class="btn brand z-depth-0"> Delete Menu </button></a>
				<form action="" method="post" enctype="multipart/form-data">
        		<input class="btn brand z-depth-0" type="file" name="uploadfile">
        		<button class="btn brand z-depth-0" type="submit" name="submitform">Upload Image</button>
				</form> 
				
				</td>
				
			</tr>
			<?php endwhile;?>
						
		</table>	
<?php include('template/footer.php');?>

</body>
</html>
