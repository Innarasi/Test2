<?php
	require_once'connection.php';//Database Connection File
	session_start();
	$rest_id = $_SESSION["rest_id"];
?>

<?php

$del = $_GET['menu_id'];
$delete = "delete from menu where menu_id='$del'";
$run = mysqli_query($con, $delete);
	
if($run){
	echo "<script>alert('Menu has been deleted')</script>";
	echo "<script>window.open('update_menu.php','_self')</script>";
	
}
else
{
	echo "<script>alert('Error')</script>";
}



?>