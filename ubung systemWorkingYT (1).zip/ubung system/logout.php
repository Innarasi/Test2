<?php
// logout.php
session_start();

		echo "<script>alert('Logout is successful. Thanks for visit our U-Bung, Bye!')</script>";
		echo "<script>window.open('home.php?rest_id=$rest_id','_self')</script>";
session_destroy();
//header('location:home.php');
?>
