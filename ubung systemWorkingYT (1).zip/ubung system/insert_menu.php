<!DOCTYPE html>
<?php
	require_once'connection.php';//Database Connection File
	session_start();
	$rest_username = $_SESSION["rest_username"];
	
$links = mysqli_connect("localhost", "root", "", "u-bung_system") or die (mysqli_error());
$strSQL = "select * from restaurant where rest_username='$rest_username'";
$rs = mysqli_query($links, $strSQL);
$row=mysqli_fetch_array($rs);

$rest_id= $row['rest_id'];
?>


<html>
<head>
	<title>U-BUNG ONLINE SYSTEM</title>
	<meta http-equiv="content-type" content="text/html" charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
<div class="sidebar">
  <a href="#home">Home</a>
  <a href="#login">Login</a>
  <a href="#despatcher">Despatcher</a>
  <a class="active" href="startbootstrap-sb-admin-gh-pages/index.html">Restaurant</a>
  <a href="#admin">Admin</a>
  <a href="#about">About</a>
</div>
<?php include('template/header.php');?>
	<section class="container grey-text">
	<h4 style="margin-left: 320px" class="center">Restaurant Menu
		<a href="logout.php" class="btn brand z-depth-0" style="float:right">Log Out</a>
	</h4>
		<form style="margin-left: 150px" action="insertion.php?rest_id=<?php echo $rest_id;?>" method="post">
		<table align ="center" border="1" style="width:220%">
		<col width="100">

			<tr>
				<th style="text-align:center"bgcolor="#404040"><b>Menu ID &nbsp </th>
				<th style="text-align:center"bgcolor="#404040"><b>Menu Name &nbsp </th>
				<th style="text-align:center"bgcolor="#404040"><b>Menu Description &nbsp </th>
				<th style="text-align:center"bgcolor="#404040"><b>Menu Price (RM) &nbsp </th>
			</tr>
			
			<tr>
				<td><input type="text" style="width:100%" name="menu_id" placeholder="e.g: A001"> </td>
				<td><input type="text" style="width:100%" name="menu_name" placeholder="e.g: Sandwich"> </td>
				<td><input type="text" style="width:100%" name="menu_Description" placeholder="e.g: Eggs, Tuna, Vege..." > </td>
				<td><input type="text" style="width:100%" name="menu_Price" placeholder="e.g: 0.20"> </td>
			</tr>
		</table>	
		<br>

		<input class="btn brand z-depth-0" type="submit" name="done" value="Submit"> </form>
		<form style="margin-left: 150px" action="update_menu.php?rest_id=<?php echo $rest_id;?>" method="post" ><input class="btn brand z-depth-0" type="submit" name="back" value="Back"> 
		</form>
	 </section>
  
<?php include('template/footer.php');?>
</body>
</html>
