<?php
	$con = mysqli_connect("localhost", "root", "", "u-bung_system") or die(mysqli_error());
	
	if(!$con)
	{
		echo "Failed to connect database. Error: ".mysqli_error($con);
	
	}
	
?>