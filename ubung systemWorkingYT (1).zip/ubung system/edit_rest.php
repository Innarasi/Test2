<!DOCTYPE html>
<?php
  require_once'connection.php';//Database Connection File
  session_start();
  $rest_username = $_SESSION["rest_username"];
  
$links = mysqli_connect("localhost", "root", "", "u-bung_system") or die (mysqli_error());
$strSQL = "select * from restaurant where rest_username='$rest_username'";
$rs = mysqli_query($links, $strSQL);
$row=mysqli_fetch_array($rs);

$rest_id= $row['rest_id'];

if(isset($_POST['submit']))
	{
		$rest_contactnum =  $_POST['rest_contactnum'];
		$rest_address = $_POST['rest_address'];
		$rest_email	=  $_POST['rest_email'];
		$rest_detail =  $_POST['rest_detail'];
		$rest_registerevidence =  $_POST['rest_registerevidence'];
		$rest_status = $_POST['rest_status'];
		
		$query="UPDATE restaurant SET rest_contactnum='$rest_contactnum',rest_address='$rest_address',rest_email='$rest_email',rest_detail='$rest_detail',rest_registerevidence='$rest_registerevidence', rest_status='$rest_status' WHERE rest_username='$rest_username'";

		$result=mysqli_query($links,$query);
    if($result){
            echo "<script>alert('Update is successfull.');</script>";"<br>";
            echo "<script>window.open('rest_profile.php?rest_username=$rest_username','_self')</script>";
        } else {
            echo "<script>alert('Update is failed');</script>";
        }
    
		
	}
?>


<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<title>U-BUNG ONLINE SYSTEM</title>
<link rel="stylesheet" type="text/css" href="style.css">

<body>

<div class="sidebar">
  <a href="#home">Home</a>
  <a href="#login">Login</a>
  <a href="#despatcher">Despatcher</a>
  <a class="active" href="startbootstrap-sb-admin-gh-pages/index.html">Restaurant</a>
  <a href="#admin">Admin</a>
  <a href="#about">About</a>
</div>


  
  <?php include('template/header.php');?>
  <section class="container grey-text">
  <h4 style="margin-left: 320px" class="center">Restaurant Information
  <a href="logout.php" class="btn brand z-depth-0" style="float:right">Log Out</a>
  </h4>
  <p style="margin-left: 400px">Please fill in the information:</p>

<form style="margin-left: 400px"class="white" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">


  <table align ="center" border="1" width="700">
    <tr>
      <td>Restaurant ID:</td>
      <td><?php $query="SELECT rest_id FROM restaurant WHERE rest_id='$rest_id'";
           $result=mysqli_query($con,$query);
           while($row=mysqli_fetch_array($result))
           {echo $row[0];

           }?>
      
    </tr>
    <tr>
      <td>Restaurant name:</td>
      <td><?php $query="SELECT rest_name FROM restaurant WHERE rest_id='$rest_id'";
           $result=mysqli_query($con,$query);
           while($row=mysqli_fetch_array($result))
           {echo $row[0];

           }?>
      
    </tr>

    <tr>
      <td>Restaurant Owner Name:</td>
      <td><?php $query="SELECT rest_owner FROM restaurant WHERE rest_id='$rest_id'";
           $result=mysqli_query($con,$query);
           while($row=mysqli_fetch_array($result))
           {echo $row[0];

           }?>
      
    </tr>

    <tr>
      <td>Restaurant Contact Number:</td>
      <td><?php $query="SELECT rest_contactnum FROM restaurant WHERE rest_id='$rest_id'";
           $result=mysqli_query($con,$query);
           while($row=mysqli_fetch_array($result))
           {echo $row[0];

           }?>
           <input type="text" style="width:100%" name="rest_contactnum" placeholder="e.g: 010-2345678"></input>
      </td>
    </tr>
    <tr>
      <td>Restaurant Address:</td>
      <td><?php $query="SELECT rest_address FROM restaurant WHERE rest_id='$rest_id'";
           $result=mysqli_query($con,$query);
           while($row=mysqli_fetch_array($result))
           {echo $row[0];

           }?>
           <input type="text" style="width:100%" name="rest_address" placeholder="e.g: NO. 22, JLN WEST"></input>
      </td>
    </tr>
    <tr>
      <td>Restaurant Email:</td>
      <td><?php $query="SELECT rest_email FROM restaurant WHERE rest_id='$rest_id'";
           $result=mysqli_query($con,$query);
           while($row=mysqli_fetch_array($result))
           {echo $row[0];

           }?>
           <input type="text" style="width:100%" name="rest_email" placeholder="e.g: abc@gmail.com"></input>
      </td>
    </tr>
    <tr>
      <td>Restaurant Detail:</td>
      <td><?php $query="SELECT rest_detail FROM restaurant WHERE rest_id='$rest_id'";
           $result=mysqli_query($con,$query);
           while($row=mysqli_fetch_array($result))
           {echo $row[0];

           }?>
           <input type="text" style="width:100%" name="rest_detail" placeholder="e.g: chinese food/malay/indian... "></input>
      </td>
    </tr>
	<tr>
      <td>Company Registry Evidence:</td>
      <td><input type="file" class="btn brand z-depth-0" name="rest_registerevidence" value="Upload"> </input></td>
    </tr>
    <tr>
      <td>Restaurant Status:</td>
      <td><?php $query="SELECT rest_status FROM restaurant WHERE rest_id='$rest_id'";
           $result=mysqli_query($con,$query);
           while($row=mysqli_fetch_array($result))
           {echo $row[0];

           }?>
           <input type="text" style="width:100%" name="rest_status" placeholder="e.g: Open/Close"></input>
      </td>
    </tr>
  </table>
  
  <div class="center">
  	<br>
  	<input type="submit" name="submit" value="Submit" class="btn brand z-depth-0">
  	<input type="reset" value="Reset" class="btn brand z-depth-0"> 

</form>
  	<form action="rest_profile.php?rest_username=<?php echo $rest_username;?>" method="post"> 
		<input type="submit" name="back" value="Back" class="btn brand z-depth-0"> 
	</form>

  </div>
  
  </section>
 
<?php include('template/footer.php');?>
  

</body>
</html>