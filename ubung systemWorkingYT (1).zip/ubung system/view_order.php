<!DOCTYPE html>
<?php
	require_once'connection.php';//Database Connection File
	session_start();
	$rest_username = $_SESSION["rest_username"];
	
$links = mysqli_connect("localhost", "root", "", "u-bung_system") or die (mysqli_error());
$strSQL = "select * from restaurant where rest_username='$rest_username'";
$rs = mysqli_query($links, $strSQL);
$row=mysqli_fetch_array($rs);

$rest_id= $row['rest_id'];
?>


<html>
<head>
	<title>U-BUNG ONLINE SYSTEM</title>
	<meta http-equiv="content-type" content="text/html" charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
<div class="sidebar">
  <a href="#home">Home</a>
  <a href="#login">Login</a>
  <a href="#despatcher">Despatcher</a>
  <a class="active" href="startbootstrap-sb-admin-gh-pages/index.html">Restaurant</a>
  <a href="#admin">Admin</a>
  <a href="#about">About</a>
</div>
<?php include('template/header.php');?>
	<section class="container grey-text">
	<h4 style="margin-left: 320px" class="center">Restaurant Order
		<a href="logout.php" class="btn brand z-depth-0" style="float:right">Log Out</a>
	</h4>
	<a href="rest_profile.php?rest_id=<?php echo $rest_id;?>" method="post"> <input class="btn brand z-depth-0" type="submit" name="back" value="Back"> </a>
	<br><br>
		<table style="width:120%">
		
		<col width="150">

			<tr>
				<th style="text-align:center"bgcolor="#404040"><b>Order ID &nbsp </th>
				<th style="text-align:center"bgcolor="#404040"><b>Customer ID &nbsp </th>
				<th style="text-align:center"bgcolor="#404040"><b>Menu ID &nbsp </th>
				<th style="text-align:center"bgcolor="#404040"><b>Menu Quantity &nbsp </th>
				<th style="text-align:center"bgcolor="#404040"><b>Menu Price &nbsp </th>
				<th style="text-align:center"bgcolor="#404040"><b>Menu Total Price (RM) &nbsp </th>
				<th style="text-align:center"bgcolor="#404040"><b>Menu Charges Earned (RM) &nbsp </th>
				
				
			</tr>

				
				<?php 
			

				$result = mysqli_query($con,"SELECT * FROM orders WHERE rest_id='$rest_id'");
				 $query="SELECT * FROM orders WHERE rest_id='$rest_id'";
				   $result=mysqli_query($con,$query);
				   
				   while($row = mysqli_fetch_array($result)):?>
					   
			<tr>
				<td style="text-align: center"><?php echo $row['order_id'];?></td>
				<td style="text-align: center"><?php echo $row['id_cust'];?></td>
				<td style="text-align: center"><?php echo $row['menu_id'];?></td>
				<td style="text-align: center"><?php echo $row['menu_quantity'];?></td>
				<td style="text-align: center"><?php echo $row['menu_Price'];?></td>
				<td style="text-align: center"><?php echo $row['menu_totalprice'];?></td>
				<td style="text-align: center"><?php echo $row['charges_earn'];?></td>
				
			</tr>

			<?php endwhile;?>
			<tr>
				<th colspan="6"style="text-align:center"bgcolor="#404040"><b>Total Charges Earned (RM) &nbsp </th>
				<td style="text-align: center">
					<?php 
     					
     					 $result = mysqli_query($con,"SELECT * FROM orders WHERE rest_id='$rest_id'");

				 		 $query="SELECT SUM(charges_earn) as sum FROM orders WHERE rest_id='$rest_id'";
				  		 $result=mysqli_query($con,$query);
				   
				   		 while($row = mysqli_fetch_array($result)):

				   		 $totalcharges = $row['sum'];
				   		 echo $totalcharges;
     				?>
				</td>
			</tr>	
			<?php endwhile;?>
		</table>	
<?php include('template/footer.php');?>

</body>
</html>
