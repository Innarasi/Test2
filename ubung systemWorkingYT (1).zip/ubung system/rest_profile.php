<!DOCTYPE html>
<?php
  require_once'connection.php';//Database Connection File
  session_start();
  $rest_username = $_SESSION["rest_username"];
  
$links = mysqli_connect("localhost", "root", "", "u-bung_system") or die (mysqli_error());
$strSQL = "select * from restaurant where rest_username='$rest_username'";
$rs = mysqli_query($links, $strSQL);
$row=mysqli_fetch_array($rs);

$rest_id= $row['rest_id'];
?>

<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<title>U-BUNG ONLINE SYSTEM</title>
<link rel="stylesheet" type="text/css" href="style.css">

<body>

<div class="sidebar">
  <a href="#home">Home</a>
  <a href="#login">Login</a>
  <a href="#despatcher">Despatcher</a>
  <a class="active" href="startbootstrap-sb-admin-gh-pages/index.html">Restaurant</a>
  <a href="#admin">Admin</a>
  <a href="#about">About</a>
</div>


  
  <?php include('template/header.php');?>
  <section class="container grey-text">
  <h4 style="margin-left: 320px" class="center">Restaurant Profile
  <a href="logout.php" class="btn brand z-depth-0" style="float:right">Log Out</a>
  </h4>

  <form style="margin-left: 400px" class="white" action="read_rest.php" method="POST">
  <table align ="center" border="1" width="700">
    <tr>
      <td>Restaurant ID:</td>
      <td><?php $query="SELECT * FROM restaurant WHERE rest_username='$rest_username'";
           $result=mysqli_query($con,$query);
           while($row=mysqli_fetch_array($result))
           {echo $row[0];

           }?>
      </td>
    </tr>
    <tr>
      <td>Restaurant name:</td>
      <td><?php $query="SELECT * FROM restaurant WHERE rest_username='$rest_username'";
           $result=mysqli_query($con,$query);
           while($row=mysqli_fetch_array($result))
           {echo $row[1];

           }?>
      </td>
    </tr>

    <tr>
      <td>Restaurant Owner Name:</td>
      <td><?php $query="SELECT * FROM restaurant WHERE rest_username='$rest_username'";
           $result=mysqli_query($con,$query);
           while($row=mysqli_fetch_array($result))
           {echo $row[2];

           }?>
      </td>
    </tr>

    <tr>
      <td>Restaurant Contact Number:</td>
      <td><?php $query="SELECT * FROM restaurant WHERE rest_username='$rest_username'";
           $result=mysqli_query($con,$query);
           while($row=mysqli_fetch_array($result))
           {echo $row[3];

           }?>
      </td>
    </tr>
    <tr>
      <td>Restaurant Address:</td>
      <td><?php $query="SELECT * FROM restaurant WHERE rest_username='$rest_username'";
           $result=mysqli_query($con,$query);
           while($row=mysqli_fetch_array($result))
           {echo $row[4];

           }?>
      </td>
    </tr>
    <tr>
      <td>Restaurant Email:</td>
      <td><?php $query="SELECT * FROM restaurant WHERE rest_username='$rest_username'";
           $result=mysqli_query($con,$query);
           while($row=mysqli_fetch_array($result))
           {echo $row[5];

           }?>
      </td>
    </tr>
    <tr>
      <td>Restaurant Detail:</td>
      <td><?php $query="SELECT * FROM restaurant WHERE rest_username='$rest_username'";
           $result=mysqli_query($con,$query);
           while($row=mysqli_fetch_array($result))
           {echo $row[6];

           }?>
      </td>
    </tr>
    <tr>
      <td>Company Registry Evidence:</td>
      <td><?php $query="SELECT * FROM restaurant WHERE rest_username='$rest_username'";
           $result=mysqli_query($con,$query);
           while($row=mysqli_fetch_array($result))
           {echo $row[7];

           }?>
      </td>
    </tr>
    <tr>
      <td>Restaurant Status:</td>
      <td><?php $query="SELECT * FROM restaurant WHERE rest_username='$rest_username'";
           $result=mysqli_query($con,$query);
           while($row=mysqli_fetch_array($result))
           {echo $row[8];

           }?>
      </td>
    </tr>
  </table>
  
  <div class="center">
  <br>
  <a href="edit_rest.php?rest_username=<?php echo $rest_username;?>"><input type="button" name="edit" value="Edit" class="btn brand z-depth-0"></a>
  <a href="update_menu.php?rest_username=<?php echo $rest_username;?>"><input type="button" name="updatemenu" value="Update Menu" class="btn brand z-depth-0"></a>
  <a href="view_order.php?rest_username=<?php echo $rest_username;?>"><input type="button" name="vieworder" value="View Order" class="btn brand z-depth-0"></a>
  </div>
  </form>
  </section>
 
<?php include('template/footer.php');?>
  

</body>
</html>

