<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>U-BUNG ONLINE SYSTEM</title>
<link rel="stylesheet" type="text/css" href="style.css">

</head>

<body>

<div class="sidebar">
  <a  href="#home">Home</a>
  <a  href="#login">Login</a>
  <a href="#despatcher">Despatcher</a>
  <a class="active" href="startbootstrap-sb-admin-gh-pages/index.html">Restaurant</a>
  <a href="#admin">Admin</a>
  <a href="#about">About</a>
</div>


  
  <?php include('template/header.php');?>
  
  <section class="container grey-text">
  <h4 style="margin-left: 230px" class="center">Restaurant Login</h4>
  <form style="margin-left: 420px" class="white" action="login_rest.php" method="POST">
  <label>Username:</label>
  <input type="text" placeholder="Enter Username" name="rest_username" required>
  <label>Password:</label>
  <input type="password" placeholder="Enter Password" name="rest_password" required>
  <div class="center">
  <input type="submit" name="login" value="login" class="btn brand z-depth-0">
  </div>
  <p>Not register yet? <a href="SIGNUP_REST.php">Click here</a> to sign up now</p>
  </form>
  </section>
 
<?php include('template/footer.php');?>
  

</body>
</html>

<?php
include_once"connection.php";
session_start();

if (isset($_POST['login']))
{
  
  if(isset($_POST['rest_username']) && isset($_POST['rest_password']))
  {
    $rest_username=$_POST['rest_username'];
    $rest_password=$_POST['rest_password'];


    $sql = "select * from restaurant where rest_username='".$rest_username."' and rest_password='".$rest_password."'";
    $result = mysqli_query($con,$sql);
    $records = mysqli_num_rows($result);

    if ($records == 1)
    {
      $_SESSION['rest_username'] = $rest_username; 
      header("location:rest_profile.php?rest_username=$rest_username");
    }
    else 
    {
    echo '<script type="text/javascript">alert("Wrong Username or Password");window.location=\'login_rest.php\';</script>';
    } 
  }
} 
?>